//control.h
#pragma once

void con_init(HWND hwnd);

void con_insert(HWND hwnd);

void con_printall(HWND hwnd);

void con_select(HWND hwnd);

void con_delete(HWND hwnd);

void con_printControls(HWND hwnd);
